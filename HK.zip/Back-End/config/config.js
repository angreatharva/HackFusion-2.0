// config.js
module.exports = {
  API_KEY: "AIzaSyDLsucRmGA_eBLPGNyruSyHZQndF2Ut6s0",
  DISCOVERY_URL:
    "https://commentanalyzer.googleapis.com/$discovery/rest?version=v1alpha1",
};
